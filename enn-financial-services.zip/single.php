<?php
/**
 * Single Post Template for Insights
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  <?php while (have_posts()) : the_post(); ?>
    
    <section class="page-banner">
      <div class="container">
        <div class="page-banner-content" style="max-width: 860px;">
          <div class="breadcrumbs">
            <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
            <span>/</span>
            <a href="<?php echo esc_url(home_url('/insights/')); ?>">Insights</a>
            <span>/</span>
            <span>
              <?php
              $cats = get_the_category();
              echo !empty($cats) ? esc_html($cats[0]->name) : 'Article';
              ?>
            </span>
          </div>
          <h1><?php the_title(); ?></h1>
          <div class="insight-meta" style="color: #B4BFBC; font-size: 0.9rem; margin-top: 14px;">
            <span>Category: <?php the_category(', '); ?></span>
            <span>•</span>
            <span>Published: <?php echo get_the_date('F j, Y'); ?></span>
            <span>•</span>
            <span><?php echo ceil(str_word_count(strip_tags(get_the_content())) / 200) . ' Min Read'; ?></span>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="legal-content-wrap" style="max-width: 900px; padding: 48px;">
          
          <?php if (has_post_thumbnail()) : ?>
            <div style="margin-bottom: 32px; border-radius: var(--radius-sm); overflow: hidden;">
              <?php the_post_thumbnail('large', array('style' => 'width: 100%; height: auto; display: block;')); ?>
            </div>
          <?php endif; ?>

          <div class="post-content">
            <?php the_content(); ?>
          </div>

          <!-- Highlighted Facilitator Disclaimer -->
          <div class="legal-disclaimer-highlight" style="margin-top: 36px;">
            <strong>Mandatory Facilitator Disclosure</strong>
            ENN Financial Services acts solely as an independent facilitator. We do not approve, sanction, or disburse loans directly. All credit facilities, interest rates, collateral requirements, processing tenures, and sanction terms are governed exclusively by the lending institutions' independent underwriting assessment.
          </div>

          <div style="margin-top: 36px; padding-top: 24px; border-top: 1px solid var(--color-border-subtle); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="btn btn-secondary btn-sm">← Back to All Articles</a>
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-sm">Get Assistance →</a>
          </div>

        </div>
      </div>
    </section>

  <?php endwhile; ?>
</main>

<?php get_footer(); ?>
