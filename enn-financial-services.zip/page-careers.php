<?php
/**
 * Template Name: Careers Page
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <span>Careers</span>
        </div>
        <h1>Build Your Career with ENN Financial Services</h1>
        <p class="page-banner-desc">
          Join a forward-thinking, integrity-driven corporate team committed to transforming the financial and insurance facilitation landscape in Kolkata.
        </p>
      </div>
    </div>
  </section>

  <!-- INTRO & WORK CULTURE -->
  <section class="section">
    <div class="container">
      <div class="intro-grid">
        <div class="intro-content">
          <div class="eyebrow">WORK CULTURE</div>
          <h2 class="section-title">Where Professional Growth Meets Integrity</h2>
          <div class="gold-line"></div>
          <p>
            At ENN Financial Services, we believe that exceptional client service originates with an empowered, knowledgeable, and ethically grounded team. We foster a workplace culture characterized by collaborative problem-solving, structured learning, and clear transparency.
          </p>
          <p>
            Whether guiding individual borrowers through loan documentation or assisting corporate entities with complex insurance coordination, our team members gain deep domain exposure across premier banking and insurance systems in India.
          </p>
        </div>
        <div class="intro-image-wrap">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/careers-culture.jpg'); ?>" alt="ENN Financial Services workplace culture in Kolkata" width="560" height="420">
        </div>
      </div>
    </div>
  </section>

  <!-- WHY WORK WITH US -->
  <section class="section section--offwhite">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">WHY WORK WITH US</div>
        <h2 class="section-title">A Career Grounded in Excellence</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          What makes ENN Financial Services a rewarding corporate environment for ambitious financial professionals.
        </p>
      </div>

      <div class="career-perks-grid">
        <div class="perk-card">
          <h4>Continuous Professional Learning</h4>
          <p>Develop comprehensive domain knowledge across credit evaluation, banking policies, insurance structures, and client relationship management.</p>
        </div>

        <div class="perk-card">
          <h4>Ethical, Transparent Culture</h4>
          <p>We pride ourselves on non-deceptive, client-first advisory values. You work in an environment where integrity is never compromised.</p>
        </div>

        <div class="perk-card">
          <h4>Kolkata Corporate Presence</h4>
          <p>Conveniently situated in New Alipore, our modern office provides an accessible, collaborative workplace with professional infrastructure.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- OPENINGS & TALENT FORM -->
  <section class="section" id="openings-section">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">OPPORTUNITIES</div>
        <h2 class="section-title">Current Openings</h2>
        <div class="gold-line gold-line--center"></div>
      </div>

      <div class="careers-notice-box" style="max-width: 820px; margin: 0 auto 50px auto; text-align: center;">
        <div style="width: 54px; height: 54px; border-radius: 50%; background: var(--color-gold-soft); color: var(--color-gold); display: flex; align-items: center; justify-content: center; margin: 0 auto 16px auto;">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        </div>
        <h3>No Open Vacancies Currently Listed</h3>
        <p>
          We do not have active vacancies posted at this immediate moment. However, ENN Financial Services is continually growing, and we actively invite talented, self-motivated professionals in financial services, loan documentation, client management, and insurance coordination to share their profiles.
        </p>
        <p style="font-weight: 600; color: var(--color-charcoal); margin-top: 10px;">
          Please submit your profile using the career enquiry form below for future opportunities.
        </p>
      </div>

      <div class="form-wrapper" style="max-width: 820px; margin: 0 auto;">
        <div class="form-header">
          <h3>General Career Profile Submission</h3>
          <p>Share your credentials with our HR team. We review submissions for upcoming roles matching your skills.</p>
        </div>

        <div id="career-form-response" style="display: none;"></div>

        <form id="enn-career-form" novalidate>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="career_name">Full Name <span class="req">*</span></label>
              <input type="text" id="career_name" name="career_name" class="form-control" placeholder="Enter your full name" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="career_email">Email Address <span class="req">*</span></label>
              <input type="email" id="career_email" name="career_email" class="form-control" placeholder="name@example.com" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label" for="career_phone">Mobile Number <span class="req">*</span></label>
              <input type="tel" id="career_phone" name="career_phone" class="form-control" placeholder="+91 98765 43210" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="career_role">Preferred Domain / Area of Expertise <span class="req">*</span></label>
              <select id="career_role" name="career_role" class="form-control" required>
                <option value="">Select your area of expertise</option>
                <option value="Loan Facilitation & Credit Analysis">Loan Facilitation & Credit Analysis</option>
                <option value="Insurance Coordination & Support">Insurance Coordination & Support</option>
                <option value="Client Relationship & Business Development">Client Relationship & Business Development</option>
                <option value="Documentation & Back-Office Operations">Documentation & Back-Office Operations</option>
                <option value="Digital Marketing & Content">Digital Marketing & Content</option>
                <option value="General Corporate Support">General Corporate Support</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="career_linkedin">LinkedIn Profile / Portfolio URL</label>
            <input type="url" id="career_linkedin" name="career_linkedin" class="form-control" placeholder="https://linkedin.com/in/yourprofile">
          </div>

          <div class="form-group">
            <label class="form-label" for="career_summary">Professional Summary & Key Experience</label>
            <textarea id="career_summary" name="career_summary" class="form-control" rows="4" placeholder="Briefly describe your background, years of experience, and career aspirations..."></textarea>
          </div>

          <div class="form-group">
            <label class="form-checkbox-label">
              <input type="checkbox" name="career_consent" id="career_consent" required checked>
              <span>I consent to ENN Financial Services retaining my profile and contacting me for relevant career opportunities.</span>
            </label>
          </div>

          <div style="margin-top: 24px;">
            <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
              Submit Career Profile
              <span class="btn-icon">→</span>
            </button>
          </div>
          <p style="font-size: 0.8rem; color: var(--color-text-muted); margin-top: 12px; text-align: center;">
            You may also send your updated CV directly to <a href="mailto:ennfinancialservices.kol@gmail.com">ennfinancialservices.kol@gmail.com</a> with subject "Career Application".
          </p>
        </form>
      </div>

    </div>
  </section>

</main>

<?php get_footer(); ?>
