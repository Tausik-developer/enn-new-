# ENN FINANCIAL SERVICES - WORDPRESS THEME
**Theme Name:** ENN Financial Services  
**Version:** 1.0.0  
**Website:** https://ennfinance.org/  
**Brand Aesthetic:** White & Gold Corporate Visual Identity  
**Primary Colors:** White (#FFFFFF), Off-white (#F5F5F2), Gold (#C49A45), Deep Charcoal (#172321), Text (#626B68)  
**Typography:** Headings: Poppins | Body: Inter  

---

## 1. Overview
The **ENN Financial Services** WordPress Theme is a corporate, fully responsive, and accessible theme built strictly to the specifications of ENN Financial Services. 
It supports native WordPress page templates, custom navigation menus, custom logo branding, dynamic post archives, and seamless compatibility with **Elementor Free** and **Hello Elementor** standards.

---

## 2. Included Templates & Hierarchy

| File | Purpose | Template Name / Trigger |
| :--- | :--- | :--- |
| `front-page.php` | 9-Section Corporate Homepage | Front Page (Auto-triggered for Home) |
| `page-about.php` | About Us with Mission, Vision, 6 Core Values, Approach | About Us Page Template |
| `page-services.php` | Main Services Hub (8 Loans + 16 Insurance with Live Filter) | Services Page Template |
| `page-loans.php` | Detailed 8 Loan Categories & Criteria | Loans Page Template |
| `page-insurance.php` | Detailed 16 Insurance Categories & 350 Classifications | Insurance Page Template |
| `page-careers.php` | Careers Culture, Openings Notice & Profile Form | Careers Page Template |
| `page-contact.php` | Contact Us with Kolkata Address, Emails & Validated Form | Contact Page Template |
| `page-disclaimer.php` | Statutory Facilitator Disclaimer & Disclosures | Disclaimer Page Template |
| `page.php` | Universal Page Template with Elementor support | Default Page Template |
| `index.php` | Insights Blog Listing & Category Archive with Search | Blog Posts / Insights Hub |
| `single.php` | Single Article Reading Layout with Disclaimer | Single Post View |
| `header.php` | Sticky Desktop Header, Mobile Drawer & Brand Tile | Reusable Header |
| `footer.php` | Dark Charcoal & Gold Footer with Legal Disclaimers | Reusable Footer |
| `functions.php` | Enqueues, AJAX Contact Handler, Custom Logo & Navs | Theme Functions |

---

## 3. Installation & Activation Guide

### Method A: Uploading via WordPress Dashboard
1. Compress the `enn-financial-services` folder into a `.zip` archive (`enn-financial-services.zip`).
2. Log in to your WordPress Admin dashboard (`https://ennfinance.org/wp-admin`).
3. Navigate to **Appearance > Themes > Add New > Upload Theme**.
4. Choose `enn-financial-services.zip` and click **Install Now**.
5. Once uploaded, click **Activate**.

### Method B: Uploading via FTP / cPanel File Manager
1. Connect to your web hosting via FTP or cPanel File Manager.
2. Navigate to your WordPress root: `wp-content/themes/`.
3. Upload the `enn-financial-services` folder directly into `wp-content/themes/`.
4. Log in to WordPress Admin and navigate to **Appearance > Themes**.
5. Hover over **ENN Financial Services** and click **Activate**.

---

## 4. Configuring Pages in WordPress

1. In WordPress Admin, go to **Pages > Add New Page**:
   - Create **Home**: Assign template **Front Page Template** (or set as Static Front Page under *Settings > Reading*).
   - Create **About Us**: Assign template **About Us Page**.
   - Create **Services**: Assign template **Services Page**.
   - Create **Loans**: Assign template **Loans Page** (Slug: `loans`).
   - Create **Insurance**: Assign template **Insurance Page** (Slug: `insurance`).
   - Create **Insights**: Under *Settings > Reading*, select this page as your "Posts page".
   - Create **Careers**: Assign template **Careers Page** (Slug: `careers`).
   - Create **Contact Us**: Assign template **Contact Page** (Slug: `contact`).
   - Create **Disclaimer**: Assign template **Disclaimer Page** (Slug: `disclaimer`).
   - Create **Privacy Policy**, **Terms & Conditions**, **Cookie Policy**: Use Default Template.

2. **Configure Navigation Menu:**
   - Go to **Appearance > Menus**.
   - Create a menu named "Primary Menu" and check the display location **Primary Navigation Menu**.
   - Structure:
     - Home
     - About Us
     - Services (Parent)
       - Loan & Financial Services (Sub-item)
       - Insurance Services (Sub-item)
     - Insights
     - Careers
     - Contact Us

---

## 5. Elementor Free Compatibility
- The theme supports Elementor's full-width templates (`Elementor Full Width` and `Elementor Canvas`).
- To edit any page with Elementor:
  1. Open the page in WordPress Admin.
  2. Click **Edit with Elementor**.
  3. The brand typography (Poppins and Inter) and CSS custom properties (`--color-gold`, `--color-charcoal`, etc.) are globally active across Elementor widgets.

---

## 6. Email Routing & Contact Submissions
- Form submissions from the Contact Us page are routed to:
  - `ennfinancialservices.kol@gmail.com`
  - `ennfinance.trading@gmail.com`
- Submissions are validated on the front-end (regex checks on 10-digit phone and email) and sanitized on the server via `wp_mail` in `functions.php`.
