<?php
/**
 * Header template for ENN Financial Services
 *
 * @package ENN_Financial_Services
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url(get_template_directory_uri() . '/assets/images/favicon-32.png'); ?>">
  <link rel="icon" type="image/png" href="<?php echo esc_url(get_template_directory_uri() . '/assets/images/favicon.png'); ?>">
  
  <?php wp_head(); ?>

  <!-- Organization Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "FinancialService",
    "name": "ENN Financial Services",
    "url": "https://ennfinance.org/",
    "logo": "https://ennfinance.org/assets/images/logo.jpg",
    "description": "ENN Financial Services is a premier financial services facilitator assisting individuals, businesses and corporate clients in exploring loan, financing and insurance solutions.",
    "slogan": "Your Financial Goals. Our Commitment.",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Nirala Apartment, 48D, Block C, New Alipore",
      "addressLocality": "Kolkata",
      "addressRegion": "West Bengal",
      "postalCode": "700053",
      "addressCountry": "IN"
    },
    "email": [
      "ennfinancialservices.kol@gmail.com",
      "ennfinance.trading@gmail.com"
    ]
  }
  </script>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header" id="site-header">
  <div class="container">
    <div class="header-inner">
      
      <!-- Brand Logo in Dark Tile -->
      <?php enn_the_custom_logo(); ?>

      <!-- Primary Navigation -->
      <nav class="nav-menu" id="primary-nav" aria-label="<?php esc_attr_e('Primary Navigation', 'enn-finance'); ?>">
        <?php
        if (has_nav_menu('primary')) {
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'items_wrap'     => '%3$s',
                'fallback_cb'    => false,
            ));
        } else {
            // Default corporate navigation structure
            $current_url = home_url(add_query_arg(array(), $GLOBALS['wp']->request));
        ?>
          <div class="nav-item">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-link <?php echo is_front_page() ? 'active' : ''; ?>">Home</a>
          </div>
          <div class="nav-item">
            <a href="<?php echo esc_url(home_url('/about/')); ?>" class="nav-link <?php echo is_page('about') ? 'active' : ''; ?>">About Us</a>
          </div>
          <div class="nav-item has-dropdown">
            <a href="<?php echo esc_url(home_url('/services/')); ?>" class="nav-link <?php echo is_page(array('services', 'loans', 'insurance')) ? 'active' : ''; ?>">
              Services
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </a>
            <div class="dropdown-menu">
              <a href="<?php echo esc_url(home_url('/loans/')); ?>" class="dropdown-link">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                Loan & Financial Services
              </a>
              <a href="<?php echo esc_url(home_url('/insurance/')); ?>" class="dropdown-link">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                Insurance Services
              </a>
            </div>
          </div>
          <div class="nav-item">
            <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="nav-link <?php echo (is_home() || is_singular('post') || is_category() || is_page('insights')) ? 'active' : ''; ?>">Insights</a>
          </div>
          <div class="nav-item">
            <a href="<?php echo esc_url(home_url('/careers/')); ?>" class="nav-link <?php echo is_page('careers') ? 'active' : ''; ?>">Careers</a>
          </div>
          <div class="nav-item">
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="nav-link <?php echo is_page('contact') ? 'active' : ''; ?>">Contact Us</a>
          </div>
        <?php } ?>

        <!-- Mobile Drawer CTA -->
        <div class="header-cta-mobile">
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary" style="width: 100%;">Get Assistance</a>
        </div>
      </nav>

      <!-- Desktop CTA Button -->
      <div class="header-cta-desktop">
        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">
          Get Assistance
          <span class="btn-icon">→</span>
        </a>
      </div>

      <!-- Mobile Hamburger Toggle -->
      <button class="mobile-toggle" id="mobile-toggle" aria-label="<?php esc_attr_e('Toggle Navigation', 'enn-finance'); ?>">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="3" y1="12" x2="21" y2="12"></line>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>
      </button>

    </div>
  </div>
</header>
