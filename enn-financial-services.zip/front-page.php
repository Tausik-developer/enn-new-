<?php
/**
 * Template Name: Front Page Template
 * Front page template for ENN Financial Services
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <!-- ==========================================================================
       SECTION 1 – HERO BANNER (Split-Layout)
       ========================================================================== -->
  <section class="hero-section">
    <div class="container">
      <div class="hero-grid">
        <div class="hero-content">
          <div class="eyebrow">ENN FINANCIAL SERVICES</div>
          <h1 class="hero-title">Your Financial Goals. Our Commitment.</h1>
          <p class="hero-description">
            Explore suitable loan, financing and insurance solutions with professional assistance from ENN Financial Services. We help connect individuals and businesses with relevant financial institutions and service providers.
          </p>
          <div class="btn-group">
            <a href="<?php echo esc_url(home_url('/services/')); ?>" class="btn btn-secondary">Explore Our Services</a>
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">
              Get Assistance
              <span class="btn-icon">→</span>
            </a>
          </div>
        </div>

        <div class="hero-image-wrap">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/hero-consultation.jpg'); ?>" alt="ENN Financial Services Consultation in Kolkata" width="580" height="460">
          <div class="hero-trust-badge">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            <div>
              <strong>Financial Facilitation</strong>
              <span>New Alipore, Kolkata, India</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ==========================================================================
       SECTION 2 – INTRODUCTION / WHO WE ARE
       ========================================================================== -->
  <section class="section section--offwhite">
    <div class="container">
      <div class="intro-grid">
        <div class="intro-image-wrap">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-discussion.jpg'); ?>" alt="ENN Financial Services client guidance and advisory session" width="560" height="420">
        </div>
        <div class="intro-content">
          <div class="eyebrow">WHO WE ARE</div>
          <h2 class="section-title">Financial Guidance Built Around Your Goals</h2>
          <div class="gold-line"></div>
          <p>
            At ENN Financial Services, we believe that accessing financial solutions should be clear, convenient and transparent. We assist individuals, entrepreneurs and businesses in exploring suitable financing and insurance opportunities through a customer-focused approach.
          </p>
          <div class="intro-feature-list">
            <div class="intro-feature-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Structured Facilitation</span>
            </div>
            <div class="intro-feature-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Transparent Processes</span>
            </div>
            <div class="intro-feature-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Multi-Category Reach</span>
            </div>
            <div class="intro-feature-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Customer-Centric Care</span>
            </div>
          </div>
          <a href="<?php echo esc_url(home_url('/about/')); ?>" class="btn btn-outline-gold">
            Learn More About Us
            <span class="btn-icon">→</span>
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- ==========================================================================
       SECTION 3 – OUR SERVICES
       ========================================================================== -->
  <section class="section">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">COMPREHENSIVE FACILITATION</div>
        <h2 class="section-title">Explore Our Financial Solutions</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          Discover a range of loan, financing and insurance services designed to address different personal and business requirements.
        </p>
      </div>

      <div class="prominent-services-grid">
        <!-- CARD 1: LOAN & FINANCIAL SERVICES -->
        <div class="service-card-prominent">
          <div class="service-icon-box">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
          </div>
          <h3>Loan & Financial Services</h3>
          <p>
            Explore financing opportunities for personal, professional and business requirements with assistance from ENN Financial Services.
          </p>
          <div class="service-items-list">
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Personal Loans</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Business Loans</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Home Loans</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Vehicle Loans</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Education Loans</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>MSME Financing</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Corporate Funding</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Secured Loans</span>
            </div>
          </div>
          <div class="service-card-footer">
            <a href="<?php echo esc_url(home_url('/loans/')); ?>" class="btn btn-outline-gold" style="width: 100%;">
              Explore Loan Services
              <span class="btn-icon">→</span>
            </a>
          </div>
        </div>

        <!-- CARD 2: INSURANCE SERVICES -->
        <div class="service-card-prominent">
          <div class="service-icon-box">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
          </div>
          <h3>Insurance Services</h3>
          <p>
            Explore a broad range of insurance service categories through assistance and connections with relevant insurance providers.
          </p>
          <div class="service-items-list">
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Life Insurance</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Health & Medical</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Motor & Automobile</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Property & Home</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Business & Commercial</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Marine & Shipping</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Import & Export</span>
            </div>
            <div class="service-list-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>16 Total Categories</span>
            </div>
          </div>
          <div class="service-card-footer">
            <a href="<?php echo esc_url(home_url('/insurance/')); ?>" class="btn btn-outline-gold" style="width: 100%;">
              Explore Insurance Services
              <span class="btn-icon">→</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ==========================================================================
       SECTION 4 – WHY CHOOSE ENN
       ========================================================================== -->
  <section class="section section--offwhite">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">OUR DIFFERENTIATORS</div>
        <h2 class="section-title">Why Choose ENN Financial Services?</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          We operate with a commitment to professional assistance, client clarity, and structured coordination across all financial categories.
        </p>
      </div>

      <div class="features-grid">
        <div class="feature-card">
          <div class="feature-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          </div>
          <h3>Transparency</h3>
          <p>Clear communication and a transparent approach throughout the assistance process.</p>
        </div>

        <div class="feature-card">
          <div class="feature-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
          </div>
          <h3>Customer Focus</h3>
          <p>Solutions and guidance centred around individual and business requirements.</p>
        </div>

        <div class="feature-card">
          <div class="feature-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
          </div>
          <h3>Professional Assistance</h3>
          <p>A structured approach to exploring relevant financial opportunities.</p>
        </div>

        <div class="feature-card">
          <div class="feature-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
          </div>
          <h3>Multiple Service Categories</h3>
          <p>Access to a broad range of loan, financing and insurance service categories.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ==========================================================================
       SECTION 5 – HOW IT WORKS
       ========================================================================== -->
  <section class="section">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">THE ASSISTANCE WORKFLOW</div>
        <h2 class="section-title">A Simple Approach to Financial Assistance</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          Our step-by-step facilitation methodology helps ensure your requirements are evaluated clearly and directed to relevant institutions.
        </p>
      </div>

      <div class="process-grid">
        <div class="process-card">
          <div class="process-step-badge">1</div>
          <h4>Submit Your Enquiry</h4>
          <p>Share your financial requirements with our team through our secure enquiry form or consultation channels.</p>
        </div>

        <div class="process-card">
          <div class="process-step-badge">2</div>
          <h4>Requirement Assessment</h4>
          <p>Our team understands your needs and basic eligibility requirements to identify suitable avenues.</p>
        </div>

        <div class="process-card">
          <div class="process-step-badge">3</div>
          <h4>Explore Available Options</h4>
          <p>Explore potentially suitable options from relevant institutions and providers matching your profile.</p>
        </div>

        <div class="process-card">
          <div class="process-step-badge">4</div>
          <h4>Application Assistance</h4>
          <p>Receive assistance through the relevant application process and document collation.</p>
        </div>
      </div>

      <div class="process-disclaimer-note">
        <strong>Important Facilitator Notice:</strong> ENN Financial Services operates strictly as a facilitation platform. We do not independently approve loans, disburse credit, or issue insurance policies. All underwriting decisions and policy contracts remain subject to respective institutions.
      </div>
    </div>
  </section>

  <!-- ==========================================================================
       SECTION 6 – FINANCIAL SOLUTIONS FOR DIFFERENT NEEDS
       ========================================================================== -->
  <section class="section section--offwhite">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">TARGET SEGMENTS</div>
        <h2 class="section-title">Financial Solutions for Different Needs</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          Whether you are planning personal goals or scaling corporate operations, we assist diverse clients across Kolkata and beyond.
        </p>
      </div>

      <div class="solutions-grid">
        <div class="solution-card">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/individuals.jpg'); ?>" alt="Financial solutions for individuals" class="solution-card-img" width="380" height="190">
          <div class="solution-card-body">
            <h3>Individuals</h3>
            <p>Explore personal financing, auto loans, educational guidance and personal protection options suited to your life stage.</p>
            <a href="<?php echo esc_url(home_url('/contact/?segment=individuals')); ?>" class="solution-card-link">Enquire for Personal Solutions →</a>
          </div>
        </div>

        <div class="solution-card">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/families.jpg'); ?>" alt="Financial solutions for families" class="solution-card-img" width="380" height="190">
          <div class="solution-card-body">
            <h3>Families</h3>
            <p>Explore residential home loans, comprehensive health coverage facilitation and safeguarding your family's future.</p>
            <a href="<?php echo esc_url(home_url('/contact/?segment=families')); ?>" class="solution-card-link">Enquire for Family Solutions →</a>
          </div>
        </div>

        <div class="solution-card">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/entrepreneurs.jpg'); ?>" alt="Financial solutions for entrepreneurs" class="solution-card-img" width="380" height="190">
          <div class="solution-card-body">
            <h3>Entrepreneurs</h3>
            <p>Support for seed capital connections, business establishment loans, equipment finance, and founder protection.</p>
            <a href="<?php echo esc_url(home_url('/contact/?segment=entrepreneurs')); ?>" class="solution-card-link">Enquire for Entrepreneurship →</a>
          </div>
        </div>

        <div class="solution-card">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/small-business.jpg'); ?>" alt="Financial solutions for small businesses" class="solution-card-img" width="380" height="190">
          <div class="solution-card-body">
            <h3>Small Businesses</h3>
            <p>Facilitation for working capital, merchant cash flow requirements, inventory financing and property insurance.</p>
            <a href="<?php echo esc_url(home_url('/contact/?segment=small-business')); ?>" class="solution-card-link">Enquire for Small Business →</a>
          </div>
        </div>

        <div class="solution-card">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/msme.jpg'); ?>" alt="Financial solutions for MSMEs" class="solution-card-img" width="380" height="190">
          <div class="solution-card-body">
            <h3>MSMEs</h3>
            <p>Structured assistance for government-backed MSME schemes, machinery loans, trade finance and commercial policies.</p>
            <a href="<?php echo esc_url(home_url('/contact/?segment=msme')); ?>" class="solution-card-link">Enquire for MSME Support →</a>
          </div>
        </div>

        <div class="solution-card">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/corporate.jpg'); ?>" alt="Financial solutions for corporate clients" class="solution-card-img" width="380" height="190">
          <div class="solution-card-body">
            <h3>Corporate Clients</h3>
            <p>Institutional funding facilitation, syndicated credit facilities, marine cargo, and comprehensive corporate insurance.</p>
            <a href="<?php echo esc_url(home_url('/contact/?segment=corporate')); ?>" class="solution-card-link">Enquire for Corporate Solutions →</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ==========================================================================
       SECTION 7 – INSIGHTS (DYNAMIC WORDPRESS POSTS)
       ========================================================================== -->
  <section class="section">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">KNOWLEDGE & ARTICLES</div>
        <h2 class="section-title">Financial Insights & Updates</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          Educational perspectives on personal finance, loan guidelines, business capital, and insurance awareness.
        </p>
      </div>

      <div class="insights-grid">
        <?php
        $latest_posts = new WP_Query(array(
            'posts_per_page' => 3,
            'post_status'    => 'publish',
        ));

        if ($latest_posts->have_posts()) :
            while ($latest_posts->have_posts()) : $latest_posts->the_post();
        ?>
          <article class="insight-card">
            <div class="insight-thumb-wrap">
              <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('enn-insight-thumb'); ?>
              <?php else : ?>
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/insight-personal-finance.jpg'); ?>" alt="<?php the_title_attribute(); ?>" width="380" height="200">
              <?php endif; ?>
              <span class="insight-badge">
                <?php
                $cats = get_the_category();
                echo !empty($cats) ? esc_html($cats[0]->name) : 'Insight';
                ?>
              </span>
            </div>
            <div class="insight-card-content">
              <div class="insight-meta">
                <span><?php echo get_the_date('F Y'); ?></span>
                <span>•</span>
                <span><?php echo ceil(str_word_count(strip_tags(get_the_content())) / 200) . ' Min Read'; ?></span>
              </div>
              <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              <p><?php echo wp_trim_words(get_the_excerpt(), 18); ?></p>
              <a href="<?php the_permalink(); ?>" class="insight-read-more">Read Article →</a>
            </div>
          </article>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
        ?>
          <!-- Curated Fallback Cards -->
          <article class="insight-card">
            <div class="insight-thumb-wrap">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/insight-personal-finance.jpg'); ?>" alt="Personal finance" width="380" height="200">
              <span class="insight-badge">Personal Finance</span>
            </div>
            <div class="insight-card-content">
              <div class="insight-meta"><span>April 2026</span><span>•</span><span>4 Min Read</span></div>
              <h3><a href="<?php echo esc_url(home_url('/insights/')); ?>">Understanding Loan Eligibility & Documentation for Salaried Individuals</a></h3>
              <p>Key eligibility factors, credit score benchmarks, and document readiness when exploring personal loans.</p>
              <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="insight-read-more">Read Article →</a>
            </div>
          </article>

          <article class="insight-card">
            <div class="insight-thumb-wrap">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/insight-msme-loan.jpg'); ?>" alt="MSME financing" width="380" height="200">
              <span class="insight-badge">MSME Finance</span>
            </div>
            <div class="insight-card-content">
              <div class="insight-meta"><span>March 2026</span><span>•</span><span>5 Min Read</span></div>
              <h3><a href="<?php echo esc_url(home_url('/insights/')); ?>">Working Capital vs. Term Loans: Choosing the Right Business Facility</a></h3>
              <p>How small and medium enterprises can balance short-term operational cash flow requirements with capital investments.</p>
              <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="insight-read-more">Read Article →</a>
            </div>
          </article>

          <article class="insight-card">
            <div class="insight-thumb-wrap">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/insight-insurance.jpg'); ?>" alt="Insurance awareness" width="380" height="200">
              <span class="insight-badge">Insurance Awareness</span>
            </div>
            <div class="insight-card-content">
              <div class="insight-meta"><span>March 2026</span><span>•</span><span>4 Min Read</span></div>
              <h3><a href="<?php echo esc_url(home_url('/insights/')); ?>">Essential Insurance Safeguards for Small Businesses and Commercial Entities</a></h3>
              <p>Key risk management fundamentals covering property, transit, public liability and employee medical coverage.</p>
              <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="insight-read-more">Read Article →</a>
            </div>
          </article>
        <?php endif; ?>
      </div>

      <div style="text-align: center; margin-top: 40px;">
        <a href="<?php echo esc_url(home_url('/insights/')); ?>" class="btn btn-secondary">
          View All Insights & Guides
          <span class="btn-icon">→</span>
        </a>
      </div>
    </div>
  </section>

  <!-- ==========================================================================
       SECTION 8 – FINAL CALL TO ACTION
       ========================================================================== -->
  <section class="final-cta-section">
    <div class="container">
      <div class="final-cta-box">
        <div class="eyebrow eyebrow--center" style="color: var(--color-gold-light);">CONNECT WITH OUR TEAM</div>
        <h2>Let's Explore the Right Financial Options for You</h2>
        <div class="gold-line gold-line--center"></div>
        <p>
          Tell us about your requirements and connect with the ENN Financial Services team for assistance. We guide you toward suitable financing institutions and insurance providers.
        </p>
        <div class="final-cta-buttons">
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">Get Assistance</a>
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-white btn-lg">Contact Us</a>
        </div>
      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>
