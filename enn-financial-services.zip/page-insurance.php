<?php
/**
 * Template Name: Insurance Page
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <a href="<?php echo esc_url(home_url('/services/')); ?>">Services</a>
          <span>/</span>
          <span>Insurance Services</span>
        </div>
        <h1>Insurance Services Facilitation</h1>
        <p class="page-banner-desc">
          Explore 16 broad insurance categories encompassing 350 listed service entries through structured assistance and connections with relevant insurance providers.
        </p>
      </div>
    </div>
  </section>

  <!-- FACILITATION NOTICE -->
  <section class="section section--sm">
    <div class="container">
      <div class="facilitator-callout-box">
        <strong>Important Regulatory Clarification on Insurance Facilitation:</strong>
        ENN Financial Services is a financial-services facilitator and does not directly issue insurance policies or underwrite risk. The supplied service classification covers 350 listed service entries across these 16 categories, representing the scope of insurance areas in which we assist clients in connecting with authorized insurers. Policy terms, coverage inclusions/exclusions, underwriting evaluations, and premium rates are determined solely by the respective authorized insurance providers.
      </div>
    </div>
  </section>

  <!-- 16 CATEGORIES -->
  <section class="section" style="padding-top: 0;">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">16 FACILITATED CATEGORIES</div>
        <h2 class="section-title">Comprehensive Insurance Categories</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          Find the relevant category matching your personal, professional, or commercial risk-protection requirements.
        </p>
      </div>

      <div class="insurance-grid">
        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></div>
          <h4>1. Life Insurance</h4>
          <p>Facilitation for pure term plans, whole life coverage, endowment avenues, child education plans, and family income protection solutions.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Life+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg></div>
          <h4>2. Health & Medical Insurance</h4>
          <p>Guidance for individual health policies, family floater plans, critical illness buffers, top-up health covers, and senior citizen hospitalization options.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Health+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg></div>
          <h4>3. Motor & Automobile Insurance</h4>
          <p>Facilitating statutory third-party liability and comprehensive own-damage policies for private cars, two-wheelers, taxi cabs, and commercial fleets.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Motor+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
          <h4>4. Property & Home Insurance</h4>
          <p>Assisting property owners and tenants in safeguarding residential structures, household contents, jewelry, and protection against perils and fire hazards.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Property+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg></div>
          <h4>5. Business & Commercial Insurance</h4>
          <p>Connecting commercial firms with commercial general liability (CGL), directors & officers (D&O) liability, shopkeeper packages, and cyber insurance.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Commercial+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="3"></circle><line x1="12" y1="22" x2="12" y2="8"></line><path d="M5 12H2a10 10 0 0 0 20 0h-3"></path></svg></div>
          <h4>6. Marine & Shipping Insurance</h4>
          <p>Facilitation for domestic inland transit cargo, ocean freight voyages, marine hull protection, freight forwarders liability, and port handling coverage.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Marine+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg></div>
          <h4>7. Import & Export Insurance</h4>
          <p>Protection guidelines for international trade consignments, customs bonded warehouses, letters of credit insurance compliance, and cross-border risks.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Import+Export+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 19 21 12 17 5 21 12 2"></polygon></svg></div>
          <h4>8. Travel Insurance</h4>
          <p>Assisting travelers with international tourist visas, Schengen travel compliance, student travel abroad packages, and domestic vacation coverage.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Travel+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a10 10 0 0 0-10 10c0 5.5 4.5 10 10 10s10-4.5 10-10c0-1.8-.5-3.5-1.4-5"></path><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg></div>
          <h4>9. Agriculture Insurance</h4>
          <p>Connecting agrarian producers and rural enterprises with crop weather index solutions, agricultural tractor insurance, and livestock schemes.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Agriculture+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg></div>
          <h4>10. Personal Accident Insurance</h4>
          <p>Facilitation for accidental death benefit, permanent total disability (PTD), temporary disability indemnities, and child educational support riders.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Personal+Accident')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg></div>
          <h4>11. Engineering & Construction</h4>
          <p>Assisting infrastructure builders with Contractors All Risks (CAR), Erection All Risks (EAR), Contractor's Plant & Machinery (CPM), and boiler explosion.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Engineering+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg></div>
          <h4>12. Financial & Credit Insurance</h4>
          <p>Connecting corporate suppliers with trade credit insurance against commercial buyer insolvency, political risks, and non-payment default protections.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Credit+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></div>
          <h4>13. Specialized Industry Insurance</h4>
          <p>Custom facilitation avenues for medical professionals (errors & omissions), clinical trials, aviation hangarkeepers, IT liability, and educational campuses.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Industry+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></div>
          <h4>14. Retirement & Pension</h4>
          <p>Assistance with exploring immediate and deferred annuities, guaranteed pension cash streams, and structured post-retirement financial security options.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Retirement+Insurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg></div>
          <h4>15. Reinsurance Services</h4>
          <p>Coordination assistance for specialized institutional risks, facultative placements, excess of loss layers, and reinsurance treaty linkages.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Reinsurance')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg></div>
          <h4>16. Policy & Customer Support</h4>
          <p>Dedicated facilitation for insurance policy review, endorsement corrections, renewal reminders, document collation, and claims procedure assistance.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Policy+Support')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire Category →</a>
        </div>
      </div>
    </div>
  </section>

  <!-- FINAL CTA -->
  <section class="final-cta-section">
    <div class="container">
      <div class="final-cta-box">
        <div class="eyebrow eyebrow--center" style="color: var(--color-gold-light);">EXPLORE PROTECTION OPTIONS</div>
        <h2>Connect With an Insurance Specialist</h2>
        <div class="gold-line gold-line--center"></div>
        <p>
          Tell us about your coverage requirements, business sector, or personal risk profile for structured assistance.
        </p>
        <div class="final-cta-buttons">
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">Submit Insurance Enquiry</a>
          <a href="<?php echo esc_url(home_url('/loans/')); ?>" class="btn btn-white btn-lg">Explore Loan Services</a>
        </div>
      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>
