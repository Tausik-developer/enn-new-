<?php
/**
 * Footer template for ENN Financial Services
 *
 * @package ENN_Financial_Services
 */
?>
<footer class="site-footer">
  <div class="container">
    <div class="footer-top">
      
      <!-- Col 1: Brand Info -->
      <div class="footer-col">
        <?php enn_the_custom_logo(); ?>
        <p class="footer-brand-p" style="margin-top: 18px;">
          ENN Financial Services is a corporate financial-services facilitator based in Kolkata. We simplify the exploration of loans, financing avenues, and insurance solutions through professional, customer-focused assistance.
        </p>
        <p style="font-size: 0.86rem; color: var(--color-gold); font-weight: 600;">
          Your Financial Goals. Our Commitment.
        </p>
      </div>

      <!-- Col 2: Quick Links -->
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul class="footer-links">
          <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
          <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About Us</a></li>
          <li><a href="<?php echo esc_url(home_url('/services/')); ?>">Our Services</a></li>
          <li><a href="<?php echo esc_url(home_url('/insights/')); ?>">Insights</a></li>
          <li><a href="<?php echo esc_url(home_url('/careers/')); ?>">Careers</a></li>
          <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact Us</a></li>
        </ul>
      </div>

      <!-- Col 3: Services -->
      <div class="footer-col">
        <h4>Financial Solutions</h4>
        <ul class="footer-links">
          <li><a href="<?php echo esc_url(home_url('/loans/')); ?>">Personal Loans</a></li>
          <li><a href="<?php echo esc_url(home_url('/loans/')); ?>">Business Loans</a></li>
          <li><a href="<?php echo esc_url(home_url('/loans/')); ?>">Home Loans</a></li>
          <li><a href="<?php echo esc_url(home_url('/loans/')); ?>">MSME Financing</a></li>
          <li><a href="<?php echo esc_url(home_url('/loans/')); ?>">Corporate Funding</a></li>
          <li><a href="<?php echo esc_url(home_url('/insurance/')); ?>">Insurance Services (16 Categories)</a></li>
        </ul>
      </div>

      <!-- Col 4: Contact Details -->
      <div class="footer-col">
        <h4>Contact Details</h4>
        
        <div class="footer-contact-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
          <div>
            <a href="mailto:ennfinancialservices.kol@gmail.com">ennfinancialservices.kol@gmail.com</a>
            <br>
            <a href="mailto:ennfinance.trading@gmail.com">ennfinance.trading@gmail.com</a>
          </div>
        </div>

        <div class="footer-contact-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          <div>
            Nirala Apartment, 48D, Block C, New Alipore, Kolkata, West Bengal – 700053, India.
          </div>
        </div>

        <div class="footer-contact-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
          <div>
            Mon – Sat: 10:00 AM – 6:30 PM IST
          </div>
        </div>
      </div>

    </div>

    <!-- Mandatory Facilitator Disclaimer Box -->
    <div class="footer-disclaimer-box">
      <strong>IMPORTANT REGULATORY & FACILITATION DISCLAIMER:</strong>
      ENN Financial Services operates as a financial-services facilitation platform. The company assists customers in exploring and connecting with relevant financial institutions, lenders and insurance providers. ENN Financial Services does not independently guarantee loan approval, credit facilities, loan disbursement or insurance policy issuance. All applications, eligibility assessments, underwriting decisions, approvals, disbursements, policy issuance, premiums, rates and contractual terms remain subject to the respective institution or provider. Customers should independently review the applicable terms and conditions before proceeding.
    </div>

    <!-- Bottom Legal Bar -->
    <div class="footer-bottom">
      <div>
        &copy; 2026 ENN Financial Services. All Rights Reserved.
      </div>
      <div class="footer-legal-links">
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
        <a href="<?php echo esc_url(home_url('/terms-conditions/')); ?>">Terms & Conditions</a>
        <a href="<?php echo esc_url(home_url('/disclaimer/')); ?>">Disclaimer</a>
        <a href="<?php echo esc_url(home_url('/cookie-policy/')); ?>">Cookie Policy</a>
      </div>
    </div>
  </div>
</footer>

<!-- Floating Back to Top Button -->
<div class="floating-actions">
  <button class="floating-btn floating-btn--top" aria-label="<?php esc_attr_e('Back to Top', 'enn-finance'); ?>">
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="18 15 12 9 6 15"></polyline></svg>
  </button>
</div>

<?php wp_footer(); ?>
</body>
</html>
