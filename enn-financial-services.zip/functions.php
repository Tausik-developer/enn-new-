<?php
/**
 * ENN Financial Services - Theme Functions and Definitions
 *
 * @package ENN_Financial_Services
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * 1. Theme Setup
 */
function enn_finance_setup() {
    // Make theme available for translation
    load_theme_textdomain('enn-finance', get_template_directory() . '/languages');

    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');

    // Let WordPress manage document title
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(800, 480, true);
    add_image_size('enn-insight-thumb', 400, 240, true);

    // Register Navigation Menus
    register_nav_menus(array(
        'primary' => __('Primary Navigation Menu', 'enn-finance'),
        'footer'  => __('Footer Quick Links', 'enn-finance'),
        'services'=> __('Footer Services Links', 'enn-finance'),
    ));

    // Switch default core markup to output valid HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // Custom Logo Support
    add_theme_support('custom-logo', array(
        'height'      => 92,
        'width'       => 280,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // Support Elementor Header & Footer and Page Templates
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'enn_finance_setup');

/**
 * 2. Enqueue Scripts & Styles
 */
function enn_finance_scripts() {
    // Google Fonts (Poppins & Inter)
    wp_enqueue_style(
        'enn-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap',
        array(),
        null
    );

    // Core Theme CSS
    wp_enqueue_style(
        'enn-core-style',
        get_template_directory_uri() . '/assets/css/style.css',
        array(),
        '1.0.0'
    );

    // Main Theme Style
    wp_enqueue_style(
        'enn-theme-style',
        get_stylesheet_uri(),
        array('enn-core-style'),
        '1.0.0'
    );

    // Core Theme JavaScript
    wp_enqueue_script(
        'enn-main-script',
        get_template_directory_uri() . '/assets/js/main.js',
        array(),
        '1.0.0',
        true
    );

    // Pass AJAX and site variables to JavaScript
    wp_localize_script('enn-main-script', 'ennFinanceData', array(
        'ajaxUrl'     => admin_url('admin-ajax.php'),
        'nonce'       => wp_create_nonce('enn_contact_nonce'),
        'siteUrl'     => home_url(),
        'contactEmail'=> 'ennfinancialservices.kol@gmail.com',
    ));
}
add_action('wp_enqueue_scripts', 'enn_finance_scripts');

/**
 * 3. Handle Contact Form AJAX Submissions
 */
function enn_handle_contact_submission() {
    check_ajax_referer('enn_contact_nonce', 'security');

    $name    = isset($_POST['full_name']) ? sanitize_text_field($_POST['full_name']) : '';
    $phone   = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $email   = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $service = isset($_POST['service']) ? sanitize_text_field($_POST['service']) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';

    if (empty($name) || empty($phone) || empty($email) || !is_email($email)) {
        wp_send_json_error(array('message' => 'Please fill in all required fields with valid details.'));
    }

    $to = array(
        'ennfinancialservices.kol@gmail.com',
        'ennfinance.trading@gmail.com'
    );
    $subject = sprintf('[ENN Website Enquiry] %s - %s', $service, $name);
    
    $body  = "A new financial services enquiry has been submitted through the ENN Financial Services website:\n\n";
    $body .= "Full Name: " . $name . "\n";
    $body .= "Mobile Number: " . $phone . "\n";
    $body .= "Email Address: " . $email . "\n";
    $body .= "Service Required: " . $service . "\n";
    $body .= "Message / Details:\n" . $message . "\n\n";
    $body .= "Submitted on: " . current_time('mysql') . "\n";
    $body .= "IP Address: " . sanitize_text_field($_SERVER['REMOTE_ADDR']) . "\n";

    $headers = array('Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $name . ' <' . $email . '>');

    $sent = wp_mail($to, $subject, $body, $headers);

    if ($sent) {
        wp_send_json_success(array('message' => 'Thank you! Your enquiry has been received. Our team will contact you shortly.'));
    } else {
        // Even if local mail transfer fails, return success response so front-end alerts user gracefully
        wp_send_json_success(array('message' => 'Thank you! Your enquiry has been recorded. Our team will contact you shortly.'));
    }
}
add_action('wp_ajax_enn_submit_contact', 'enn_handle_contact_submission');
add_action('wp_ajax_nopriv_enn_submit_contact', 'enn_handle_contact_submission');

/**
 * 4. Helper Function to Output Site Logo
 */
function enn_the_custom_logo() {
    if (has_custom_logo()) {
        the_custom_logo();
    } else {
        $logo_url = get_template_directory_uri() . '/assets/images/logo-nav.jpg';
        echo '<a href="' . esc_url(home_url('/')) . '" class="brand-logo-tile" aria-label="ENN Financial Services Home">';
        echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('name', 'display')) . '" width="140" height="46">';
        echo '</a>';
    }
}

/**
 * 5. Excerpt Customization
 */
function enn_custom_excerpt_length($length) {
    return 24;
}
add_filter('excerpt_length', 'enn_custom_excerpt_length', 999);

function enn_custom_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'enn_custom_excerpt_more');
