<?php
/**
 * Template Name: Disclaimer Page
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <span>Legal Disclaimer</span>
        </div>
        <h1>Legal & Regulatory Disclaimer</h1>
        <p class="page-banner-desc">
          Important regulatory disclosures, terms of facilitation, and scope of operations for ENN Financial Services.
        </p>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="legal-content-wrap">
        
        <!-- PROMINENT MANDATORY FACILITATOR DISCLAIMER BOX -->
        <div class="legal-disclaimer-highlight">
          <strong>MANDATORY STATUTORY & REGULATORY DISCLAIMER:</strong>
          "ENN Financial Services operates as a financial-services facilitation platform. The company assists customers in exploring and connecting with relevant financial institutions, lenders and insurance providers. ENN Financial Services does not independently guarantee loan approval, credit facilities, loan disbursement or insurance policy issuance. All applications, eligibility assessments, underwriting decisions, approvals, disbursements, policy issuance, premiums, rates and contractual terms remain subject to the respective institution or provider. Customers should independently review the applicable terms and conditions before proceeding."
        </div>

        <h2>1. Business Model & Nature of Services</h2>
        <p>
          ENN Financial Services (website: <a href="https://ennfinance.org/">https://ennfinance.org/</a>) provides consultation, informational guidance, and operational assistance to individuals, commercial establishments, and corporate entities in India. Our principal business function is acting as a facilitator connecting clients to recognized financial institutions, scheduled commercial banks, non-banking financial companies (NBFCs), and authorized insurance companies.
        </p>
        <p>
          ENN Financial Services is <strong>not</strong> a direct lending institution, banking entity, deposit-taking institution, or insurance underwriter. We do not independently issue credit instruments, approve loan sanctions, execute debt disbursements, or underwrite insurance policies.
        </p>

        <h2>2. Non-Guarantee of Credit Approval or Insurance Issuance</h2>
        <p>
          The submission of an application or enquiry through this website, by email, or through any communication with an ENN Financial Services representative does not guarantee, imply, or constitute:
        </p>
        <ul>
          <li>Automatic approval or pre-sanction of any loan or credit facility.</li>
          <li>Guaranteed interest rates, tenures, processing fees, or waivers.</li>
          <li>Immediate or guaranteed issuance of any life or general insurance policy.</li>
          <li>Guarantee of claim settlement by any insurance provider.</li>
        </ul>
        <p>
          All financing offers, underwriting assessments, credit risk scoring, interest rate determinations, policy wording, exclusions, deductibles, and premiums remain at the sole and independent discretion of the partner lender or insurance carrier.
        </p>

        <h2>3. Informational Nature of Website Content</h2>
        <p>
          The content, insights, articles, loan category summaries, and service descriptions presented on this website are provided strictly for general informational and educational purposes. While we strive to maintain accurate, up-to-date industry information, financial guidelines, lending norms, and regulatory mandates are subject to continuous revision by regulatory bodies such as the Reserve Bank of India (RBI) and the Insurance Regulatory and Development Authority of India (IRDAI).
        </p>
        <p>
          Visitors and prospective borrowers should not treat any material on this website as formal legal, accounting, tax, or investment advice. You are urged to independently examine all formal loan agreements and insurance policy schedules with qualified professional advisors prior to entering into contractual commitments.
        </p>

        <h2>4. 16 Insurance Categories and 350 Service Classifications</h2>
        <p>
          References across this website to 16 insurance service categories encompassing 350 listed service entries designate the classification spectrum of risk domains wherein ENN Financial Services provides facilitation support. These classifications do not constitute 350 proprietary or independently underwritten insurance products issued by ENN Financial Services.
        </p>

        <h2>5. Limitation of Liability</h2>
        <p>
          To the maximum extent permitted by applicable Indian laws, ENN Financial Services, its proprietors, affiliates, employees, and authorized agents shall not be liable for any direct, indirect, incidental, consequential, or punitive damages arising from decisions of partner institutions, discrepancies between estimates and final sanction terms, or interruptions in transmission.
        </p>

        <h2>6. Contact for Clarifications</h2>
        <p>
          For questions or formal clarifications regarding our facilitation business model or regulatory posture, please write to:
        </p>
        <p>
          <strong>ENN Financial Services</strong><br>
          Nirala Apartment, 48D, Block C, New Alipore,<br>
          Kolkata, West Bengal – 700053, India.<br>
          Email: <a href="mailto:ennfinancialservices.kol@gmail.com">ennfinancialservices.kol@gmail.com</a>
        </p>

      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>
