<?php
/**
 * Template Name: Loans Page
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <a href="<?php echo esc_url(home_url('/services/')); ?>">Services</a>
          <span>/</span>
          <span>Loan & Financial Services</span>
        </div>
        <h1>Loan & Financial Services Facilitation</h1>
        <p class="page-banner-desc">
          Explore financing opportunities for personal, professional and business requirements with structured assistance from ENN Financial Services.
        </p>
      </div>
    </div>
  </section>

  <!-- FACILITATOR NOTICE -->
  <section class="section section--sm">
    <div class="container">
      <div class="facilitator-callout-box">
        <strong>Institutional Terms & Assessment Disclaimer:</strong>
        ENN Financial Services acts solely as an independent facilitator between applicants and recognized financial institutions or lenders. We do not approve, sanction, or disburse loans directly. All credit approvals, borrowing limits, interest rates, processing tenures, and charges are governed by the lending institutions' underwriting parameters.
      </div>
    </div>
  </section>

  <!-- 8 LOAN CATEGORIES -->
  <section class="section" style="padding-top: 0;">
    <div class="container">
      <div class="loans-grid">
        
        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></div>
          <h4>Personal Loans</h4>
          <p>Designed for salaried professionals and self-employed individuals requiring collateral-free funding for immediate personal needs, wedding expenditures, medical treatments, or debt restructuring.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> CIBIL score, monthly net income, employment stability, KYC documentation.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=Personal+Loans')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for Personal Loan →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg></div>
          <h4>Business Loans</h4>
          <p>Facilitation for established proprietary firms, partnerships, and private companies seeking non-collateral or collateral-backed business expansion capital, operating cash flow, or procurement funding.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> Business vintage (2+ years), GST filings, audited balance sheets, banking cash turnover.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=Business+Loans')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for Business Loan →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
          <h4>Home Loans</h4>
          <p>Assisting home buyers and investors with housing finance options for new flat acquisitions, plot purchases with construction, home remodeling, and attractive balance transfer alternatives.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> Property legal title clearance, sanctioned building plan, repayment capability, LTV norms.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=Home+Loans')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for Home Loan →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg></div>
          <h4>Vehicle Loans</h4>
          <p>Guidance for financing private passenger cars, commercial transport vehicles, logistics fleets, and two-wheelers through top auto-finance lenders.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> On-road invoice quotation, down payment feasibility, credit repayment track.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=Vehicle+Loans')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for Vehicle Loan →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path></svg></div>
          <h4>Education Loans</h4>
          <p>Connecting meritorious students and their families with educational financing programs covering university tuition, lodging, and academic materials for premier Indian and global institutions.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> Admission letter, course accreditation, co-borrower income standing, visa eligibility.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=Education+Loans')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for Education Loan →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg></div>
          <h4>MSME Financing</h4>
          <p>Supporting Micro, Small and Medium Enterprises across West Bengal to access government-assisted priority sector lending schemes, CGTMSE coverage, and machinery term loans.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> Udyam registration, manufacturing/service classification, tax returns, project report.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=MSME+Financing')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for MSME Financing →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M3 7h18M3 14h18M5 3v18M19 3v18"></path></svg></div>
          <h4>Corporate Funding</h4>
          <p>Facilitation for large-scale corporate borrowers requiring structured debt instruments, syndicated bank consortium facilities, non-fund-based limits (LC/BG), and project finance.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> Corporate credit ratings, debt service coverage ratio (DSCR), capital structure, collateral security.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=Corporate+Funding')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for Corporate Funding →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></div>
          <h4>Secured Loans</h4>
          <p>Assisting borrowers in leveraging residential, commercial, or industrial properties through Loan Against Property (LAP) to unlock liquidity for business expansion or debt consolidation.</p>
          <div style="font-size: 0.82rem; color: var(--color-text-muted); margin-bottom: 14px; border-top: 1px solid var(--color-border-subtle); padding-top: 10px;">
            <strong>Key Considerations:</strong> Property valuation report, encumbrance certificate, municipal sanction, regular income proof.
          </div>
          <a href="<?php echo esc_url(home_url('/contact/?service=Secured+Loans')); ?>" class="btn btn-outline-gold btn-sm" style="margin-top: auto;">Enquire for Secured Loan →</a>
        </div>

      </div>
    </div>
  </section>

  <!-- FINAL CTA -->
  <section class="final-cta-section">
    <div class="container">
      <div class="final-cta-box">
        <div class="eyebrow eyebrow--center" style="color: var(--color-gold-light);">START YOUR ENQUIRY</div>
        <h2>Ready to Explore Financing Options?</h2>
        <div class="gold-line gold-line--center"></div>
        <p>
          Share your requirements with ENN Financial Services for structured assistance and clear institutional guidance.
        </p>
        <div class="final-cta-buttons">
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">Submit Loan Enquiry</a>
          <a href="<?php echo esc_url(home_url('/services/')); ?>" class="btn btn-white btn-lg">View All Services</a>
        </div>
      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>
