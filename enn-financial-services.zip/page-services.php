<?php
/**
 * Template Name: Services Page
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <span>Services</span>
        </div>
        <h1>Explore Our Financial & Insurance Solutions</h1>
        <p class="page-banner-desc">
          ENN Financial Services connects individuals, entrepreneurs, and corporations with relevant lenders, financial institutions, and insurance providers across India.
        </p>
      </div>
    </div>
  </section>

  <!-- FILTER & SEARCH BAR -->
  <section class="section section--sm" style="padding-bottom: 0;">
    <div class="container">
      <div class="service-filter-bar">
        <div class="service-filter-group">
          <button class="service-filter-btn active" data-filter="all">All Solutions</button>
          <button class="service-filter-btn" data-filter="loans">Loan & Financing (8)</button>
          <button class="service-filter-btn" data-filter="insurance">Insurance Categories (16)</button>
        </div>
        <div class="service-search-box">
          <svg class="service-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          <input type="text" id="service-search-input" placeholder="Search loans or insurance categories..." aria-label="Search financial services">
        </div>
      </div>

      <div class="facilitator-callout-box">
        <strong>Important Facilitator Information:</strong>
        ENN Financial Services operates as a facilitation platform. All financing facilities, loan eligibility, interest rates, approval, disbursement, and insurance policy issuance remain strictly subject to the respective financial institution's or insurance provider's terms and assessments.
      </div>
    </div>
  </section>

  <!-- PART A: LOAN SERVICES -->
  <section class="section" id="loans-section">
    <div class="container">
      <div class="section-header">
        <div class="eyebrow">PART A</div>
        <h2 class="section-title">Loan & Financial Services</h2>
        <div class="gold-line"></div>
        <p class="section-subtitle" style="margin-left: 0;">
          Explore financing opportunities for personal, professional and business requirements with assistance from ENN Financial Services.
        </p>
      </div>

      <div class="loans-grid">
        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></div>
          <h4>Personal Loans</h4>
          <p>Assistance for unsecured credit exploration catering to personal milestones, weddings, medical contingencies, and planned expenses.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Personal+Loans')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg></div>
          <h4>Business Loans</h4>
          <p>Facilitating connections for business expansion capital, inventory purchases, working capital enhancement, and equipment upgrading.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Business+Loans')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
          <h4>Home Loans</h4>
          <p>Guidance for residential property acquisition, flat purchase, home construction, renovation, and balance transfer options.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Home+Loans')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg></div>
          <h4>Vehicle Loans</h4>
          <p>Assistance in exploring auto finance options for commercial vehicles, four-wheelers, and two-wheelers through leading lenders.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Vehicle+Loans')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path></svg></div>
          <h4>Education Loans</h4>
          <p>Guidance for students and parents seeking educational financing for domestic higher degrees and overseas university study programs.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Education+Loans')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg></div>
          <h4>MSME Financing</h4>
          <p>Connecting Micro, Small and Medium Enterprises with bank schemes, institutional working capital lines, and machinery loans.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=MSME+Financing')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M3 7h18M3 14h18M5 3v18M19 3v18"></path></svg></div>
          <h4>Corporate Funding</h4>
          <p>Structured coordination for corporate debt, syndicated bank facilities, invoice discounting, and project finance opportunities.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Corporate+Funding')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>

        <div class="loan-card">
          <div class="loan-card-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></div>
          <h4>Secured Loans</h4>
          <p>Assisting clients in unlocking capital against residential, commercial, or industrial property assets through structured mortgages.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Secured+Loans')); ?>" class="loan-card-link">Enquire Now →</a>
        </div>
      </div>

      <div style="text-align: center;">
        <a href="<?php echo esc_url(home_url('/loans/')); ?>" class="btn btn-secondary">
          View Complete Loan Details & Criteria
          <span class="btn-icon">→</span>
        </a>
      </div>
    </div>
  </section>

  <!-- PART B: INSURANCE SERVICES -->
  <section class="section section--offwhite" id="insurance-section">
    <div class="container">
      <div class="section-header">
        <div class="eyebrow">PART B</div>
        <h2 class="section-title">Insurance Services (16 Categories)</h2>
        <div class="gold-line"></div>
        <p class="section-subtitle" style="margin-left: 0;">
          Explore a broad range of insurance service categories through assistance and connections with relevant insurance providers. Across these 16 categories, we facilitate exploration covering 350 listed service entries.
        </p>
      </div>

      <div class="insurance-grid">
        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></div>
          <h4>Life Insurance</h4>
          <p>Term life, whole life, endowment, and family security options from licensed insurers.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Life+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg></div>
          <h4>Health & Medical</h4>
          <p>Individual health, family floater, critical illness and senior citizen medical coverage options.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Health+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg></div>
          <h4>Motor & Automobile</h4>
          <p>Comprehensive and third-party coverage for two-wheelers, private cars, and commercial fleets.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Motor+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
          <h4>Property & Home</h4>
          <p>Safeguarding residential dwellings, structural assets, home contents, and fire/peril protection.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Property+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg></div>
          <h4>Business & Commercial</h4>
          <p>Commercial general liability, shopkeeper packages, business interruption, and office assets.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Commercial+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="3"></circle><line x1="12" y1="22" x2="12" y2="8"></line><path d="M5 12H2a10 10 0 0 0 20 0h-3"></path></svg></div>
          <h4>Marine & Shipping</h4>
          <p>Inland transit, ocean cargo protection, hull and vessel insurance facilitation for logistics.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Marine+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg></div>
          <h4>Import & Export</h4>
          <p>Cross-border trade protection, international cargo coverage, and customs-compliant policies.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Import+Export+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 19 21 12 17 5 21 12 2"></polygon></svg></div>
          <h4>Travel Insurance</h4>
          <p>International and domestic travel protection covering medical emergencies, trip delay and baggage.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Travel+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a10 10 0 0 0-10 10c0 5.5 4.5 10 10 10s10-4.5 10-10c0-1.8-.5-3.5-1.4-5"></path><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg></div>
          <h4>Agriculture Insurance</h4>
          <p>Crop protection guidelines, tractor/farm machinery coverage, and agricultural livestock options.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Agriculture+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg></div>
          <h4>Personal Accident</h4>
          <p>Protection against accidental disability, injury, and financial indemnity for earning family members.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Personal+Accident')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg></div>
          <h4>Engineering & Construction</h4>
          <p>Contractors all-risk (CAR), erection all-risk (EAR), plant & machinery breakdown protection.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Engineering+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg></div>
          <h4>Financial & Credit</h4>
          <p>Trade credit protection, insolvency safeguards, and commercial counterparty risk mitigation.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Credit+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></div>
          <h4>Specialized Industry</h4>
          <p>Tailored coverage categories for healthcare entities, educational institutions, IT and manufacturing.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Industry+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></div>
          <h4>Retirement & Pension</h4>
          <p>Annuity plans, retirement corpus building avenues, and post-employment financial security.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Retirement+Insurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg></div>
          <h4>Reinsurance Services</h4>
          <p>Facilitation and advisory connections for treaty and facultative reinsurance treaty arrangements.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Reinsurance')); ?>" class="category-card-link">Enquire →</a>
        </div>

        <div class="category-card">
          <div class="category-card-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg></div>
          <h4>Policy & Support</h4>
          <p>Assistance with policy renewals, document filing, endorsement coordination, and claims guidance.</p>
          <a href="<?php echo esc_url(home_url('/contact/?service=Policy+Support')); ?>" class="category-card-link">Enquire →</a>
        </div>
      </div>

      <div style="text-align: center; margin-top: 40px;">
        <a href="<?php echo esc_url(home_url('/insurance/')); ?>" class="btn btn-secondary">
          View Complete Insurance Facilitation Guide
          <span class="btn-icon">→</span>
        </a>
      </div>
    </div>
  </section>

  <!-- FINAL CTA -->
  <section class="final-cta-section">
    <div class="container">
      <div class="final-cta-box">
        <div class="eyebrow eyebrow--center" style="color: var(--color-gold-light);">CUSTOM CONSULTATION</div>
        <h2>Need Guidance on the Right Option?</h2>
        <div class="gold-line gold-line--center"></div>
        <p>
          Contact ENN Financial Services to review your requirements with our corporate assistance desk in Kolkata.
        </p>
        <div class="final-cta-buttons">
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">Get Assistance Now</a>
          <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-white btn-lg">Return to Home</a>
        </div>
      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>
