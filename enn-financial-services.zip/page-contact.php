<?php
/**
 * Template Name: Contact Page
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <span>Contact Us</span>
        </div>
        <h1>Connect with ENN Financial Services</h1>
        <p class="page-banner-desc">
          Reach out to our consultation desk in New Alipore, Kolkata. We are ready to assist you in exploring suitable loan, financing and insurance avenues.
        </p>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="contact-layout-grid">
        
        <!-- LEFT COLUMN: OFFICE & CONTACT DETAILS -->
        <div class="contact-info-panel">
          <div class="contact-card-box">
            <div class="eyebrow">OUR OFFICE</div>
            <h3 style="margin-bottom: 18px; font-size: 1.35rem;">Visit Our Kolkata Office</h3>
            
            <div class="contact-detail-row">
              <div class="contact-detail-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
              </div>
              <div class="contact-detail-text">
                <h4>Office Address</h4>
                <p>
                  Nirala Apartment, 48D, Block C,<br>
                  New Alipore, Kolkata,<br>
                  West Bengal – 700053, India.
                </p>
              </div>
            </div>

            <div class="contact-detail-row">
              <div class="contact-detail-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
              </div>
              <div class="contact-detail-text">
                <h4>Business Email Addresses</h4>
                <p>
                  <a href="mailto:ennfinancialservices.kol@gmail.com">ennfinancialservices.kol@gmail.com</a>
                  <br>
                  <a href="mailto:ennfinance.trading@gmail.com">ennfinance.trading@gmail.com</a>
                </p>
              </div>
            </div>

            <div class="contact-detail-row">
              <div class="contact-detail-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              </div>
              <div class="contact-detail-text">
                <h4>Working Hours</h4>
                <p>
                  Monday – Saturday: 10:00 AM – 6:30 PM IST<br>
                  Sunday: Closed
                </p>
              </div>
            </div>
          </div>

          <!-- GOOGLE MAP EMBED (New Alipore, Kolkata) -->
          <div class="map-embed-container">
            <iframe 
              title="ENN Financial Services Office Location in New Alipore Kolkata"
              src="https://maps.google.com/maps?q=New%20Alipore,%20Kolkata,%20West%20Bengal%20700053,%20India&t=&z=14&ie=UTF8&iwloc=&output=embed" 
              loading="lazy" 
              referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>

          <div class="facilitator-callout-box" style="margin-top: 10px;">
            <strong>Assistance Notice</strong>
            ENN Financial Services operates strictly as an independent facilitator. We do not independently disburse loans or issue insurance policies. All sanctions remain at the discretion of the partner institutions.
          </div>
        </div>

        <!-- RIGHT COLUMN: ENQUIRY FORM -->
        <div class="form-wrapper">
          <div class="form-header">
            <div class="eyebrow">SUBMIT AN ENQUIRY</div>
            <h3>How Can We Assist You?</h3>
            <p>Fill out the form below. Enquiries are routed directly to our desk at <span style="color: var(--color-gold);">ennfinancialservices.kol@gmail.com</span>.</p>
          </div>

          <div id="contact-form-response" style="display: none;"></div>

          <form id="enn-contact-form" novalidate>
            <div class="form-group">
              <label class="form-label" for="full_name">Full Name <span class="req">*</span></label>
              <input type="text" id="full_name" name="full_name" class="form-control" placeholder="Enter your full name" required autocomplete="name">
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label" for="phone">Mobile Number <span class="req">*</span></label>
                <input type="tel" id="phone" name="phone" class="form-control" placeholder="e.g. 9876543210" required autocomplete="tel">
              </div>
              <div class="form-group">
                <label class="form-label" for="email">Email Address <span class="req">*</span></label>
                <input type="email" id="email" name="email" class="form-control" placeholder="name@example.com" required autocomplete="email">
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" for="service">Service Required <span class="req">*</span></label>
              <select id="service" name="service" class="form-control" required>
                <option value="">Select the service you require assistance with</option>
                <optgroup label="Loan & Financial Services">
                  <option value="Personal Loans">Personal Loans</option>
                  <option value="Business Loans">Business Loans</option>
                  <option value="Home Loans">Home Loans</option>
                  <option value="Vehicle Loans">Vehicle Loans</option>
                  <option value="Education Loans">Education Loans</option>
                  <option value="MSME Financing">MSME Financing</option>
                  <option value="Corporate Funding">Corporate Funding</option>
                  <option value="Secured Loans">Secured Loans</option>
                </optgroup>
                <optgroup label="Insurance Services">
                  <option value="Insurance Services">Insurance Services (General Exploration)</option>
                  <option value="Life Insurance">Life Insurance</option>
                  <option value="Health Insurance">Health & Medical Insurance</option>
                  <option value="Motor Insurance">Motor & Automobile Insurance</option>
                  <option value="Property Insurance">Property & Home Insurance</option>
                  <option value="Commercial Insurance">Business & Commercial Insurance</option>
                  <option value="Marine Insurance">Marine & Shipping Insurance</option>
                  <option value="Import Export Insurance">Import & Export Insurance</option>
                  <option value="Other Insurance">Other Insurance Categories</option>
                </optgroup>
                <option value="Other">Other Requirement</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label" for="message">Requirement Details / Message</label>
              <textarea id="message" name="message" class="form-control" placeholder="Briefly describe your financing amount or insurance scope, preferred tenure, or specific objectives..."></textarea>
            </div>

            <div class="form-group">
              <label class="form-checkbox-label" for="consent">
                <input type="checkbox" name="consent" id="consent" required>
                <span>
                  I confirm that the details provided are accurate and authorize ENN Financial Services to contact me regarding my enquiry in accordance with the <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" target="_blank">Privacy Policy</a> and <a href="<?php echo esc_url(home_url('/disclaimer/')); ?>" target="_blank">Disclaimer</a>.
                </span>
              </label>
            </div>

            <div style="display: none;" aria-hidden="true">
              <input type="text" id="honeypot" name="honeypot" tabindex="-1" autocomplete="off">
            </div>

            <div style="margin-top: 24px;">
              <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                Submit Assistance Enquiry
                <span class="btn-icon">→</span>
              </button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </section>

</main>

<script>
  // Auto-select dropdown from query parameters
  document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const serviceParam = urlParams.get('service');
    if (serviceParam) {
      const select = document.getElementById('service');
      if (select) {
        for (let i = 0; i < select.options.length; i++) {
          if (select.options[i].value.toLowerCase().includes(serviceParam.toLowerCase()) || 
              serviceParam.toLowerCase().includes(select.options[i].value.toLowerCase())) {
            select.selectedIndex = i;
            break;
          }
        }
      }
    }
  });
</script>

<?php get_footer(); ?>
