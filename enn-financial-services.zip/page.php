<?php
/**
 * Standard Page Template
 * Fully compatible with Elementor Free and Gutenberg Blocks
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  <?php while (have_posts()) : the_post(); ?>
    
    <!-- Render Elementor or standard page content -->
    <?php if (class_exists('\\Elementor\\Plugin') && \Elementor\Plugin::$instance->documents->get(get_the_ID())->is_built_with_elementor()) : ?>
      <div class="elementor-content-wrap">
        <?php the_content(); ?>
      </div>
    <?php else : ?>
      <section class="page-banner">
        <div class="container">
          <div class="page-banner-content">
            <div class="breadcrumbs">
              <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
              <span>/</span>
              <span><?php the_title(); ?></span>
            </div>
            <h1><?php the_title(); ?></h1>
          </div>
        </div>
      </section>

      <section class="section">
        <div class="container">
          <div class="legal-content-wrap">
            <?php the_content(); ?>
          </div>
        </div>
      </section>
    <?php endif; ?>

  <?php endwhile; ?>
</main>

<?php get_footer(); ?>
