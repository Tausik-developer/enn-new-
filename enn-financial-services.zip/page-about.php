<?php
/**
 * Template Name: About Us Page
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <span>About Us</span>
        </div>
        <h1>About ENN Financial Services</h1>
        <p class="page-banner-desc">
          Your trusted financial services facilitation partner in Kolkata, bridging the gap between individuals, businesses, and leading institutions.
        </p>
      </div>
    </div>
  </section>

  <!-- WHO WE ARE -->
  <section class="section">
    <div class="container">
      <div class="intro-grid">
        <div class="intro-content">
          <div class="eyebrow">WHO WE ARE</div>
          <h2 class="section-title">Professional Assistance Built on Integrity & Clarity</h2>
          <div class="gold-line"></div>
          <p>
            ENN Financial Services operates as a dedicated financial services facilitator. We help individuals, businesses and corporate clients explore suitable financial solutions by facilitating connections with relevant financial institutions, lenders and insurance providers.
          </p>
          <p>
            Navigating the financial and insurance landscape can often seem overwhelming with varying documentation standards, complex eligibility criteria, and diverse product categories. Our role is to simplify this exploration through objective guidance, transparent communication, and structured customer assistance.
          </p>
          <div class="facilitator-callout-box" style="margin-top: 24px;">
            <strong>Our Facilitation Principle</strong>
            We are a facilitator, connecting clients with relevant institutional options. We prioritize customer clarity, ethical coordination, and transparent expectations at every stage.
          </div>
        </div>
        <div class="intro-image-wrap">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-discussion.jpg'); ?>" alt="ENN Financial Services team advising corporate clients in Kolkata" width="560" height="420">
        </div>
      </div>
    </div>
  </section>

  <!-- MISSION & VISION -->
  <section class="section section--offwhite">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">PURPOSE & DIRECTION</div>
        <h2 class="section-title">Our Mission & Vision</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          Defined by a commitment to simplify access to financial solutions for individuals and enterprises.
        </p>
      </div>

      <div class="mission-vision-grid">
        <div class="mv-card">
          <div class="mv-card-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon></svg>
          </div>
          <h3>Our Mission</h3>
          <p>
            "To simplify access to financial opportunities by providing professional assistance, transparent communication and customer-focused facilitation."
          </p>
        </div>

        <div class="mv-card">
          <div class="mv-card-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          </div>
          <h3>Our Vision</h3>
          <p>
            "To become a trusted financial-services facilitation partner for individuals and businesses seeking accessible financial and insurance solutions."
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- CORE VALUES -->
  <section class="section">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">GUIDING PRINCIPLES</div>
        <h2 class="section-title">Our Core Values</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          The foundation of every interaction, consultation, and institutional connection at ENN Financial Services.
        </p>
      </div>

      <div class="values-grid">
        <div class="value-card">
          <div class="value-number">01</div>
          <h4>Transparency</h4>
          <p>Providing clear and honest communication regarding terms, criteria, and requirements without misleading claims.</p>
        </div>

        <div class="value-card">
          <div class="value-number">02</div>
          <h4>Trust</h4>
          <p>Building long-term dependable relationships with clients and partner institutions through ethical practices.</p>
        </div>

        <div class="value-card">
          <div class="value-number">03</div>
          <h4>Professionalism</h4>
          <p>Maintaining high standards of diligence, confidentiality, and structured execution in all facilitation workflows.</p>
        </div>

        <div class="value-card">
          <div class="value-number">04</div>
          <h4>Accessibility</h4>
          <p>Ensuring financial services and institutional options are easy to explore for businesses and individuals of all backgrounds.</p>
        </div>

        <div class="value-card">
          <div class="value-number">05</div>
          <h4>Customer Focus</h4>
          <p>Aligning guidance around the distinct financial objectives, timeframes, and constraints of each applicant.</p>
        </div>

        <div class="value-card">
          <div class="value-number">06</div>
          <h4>Integrity</h4>
          <p>Upholding strict ethical conduct, client privacy, and accurate representation of institutional guidelines.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- OUR APPROACH -->
  <section class="section section--offwhite">
    <div class="container">
      <div class="section-header section-header--center">
        <div class="eyebrow eyebrow--center">HOW WE WORK</div>
        <h2 class="section-title">Our Structured Approach</h2>
        <div class="gold-line gold-line--center"></div>
        <p class="section-subtitle">
          A methodical four-pillar framework designed to give clients peace of mind and clarity.
        </p>
      </div>

      <div class="process-grid">
        <div class="process-card">
          <div class="process-step-badge">1</div>
          <h4>Requirement Discovery</h4>
          <p>We engage in detailed discussions to grasp your precise personal or commercial capital requirements and risk priorities.</p>
        </div>

        <div class="process-card">
          <div class="process-step-badge">2</div>
          <h4>Institutional Alignment</h4>
          <p>We identify relevant lenders and authorized insurance providers whose parameters match your profile.</p>
        </div>

        <div class="process-card">
          <div class="process-step-badge">3</div>
          <h4>Documentation Guidance</h4>
          <p>We assist in assembling required documentation in accordance with institution-specific compliance standards.</p>
        </div>

        <div class="process-card">
          <div class="process-step-badge">4</div>
          <h4>Ongoing Coordination</h4>
          <p>We maintain active communication throughout the facilitation timeline to answer queries and provide updates.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- FINAL CTA -->
  <section class="final-cta-section">
    <div class="container">
      <div class="final-cta-box">
        <div class="eyebrow eyebrow--center" style="color: var(--color-gold-light);">START THE CONVERSATION</div>
        <h2>Ready to Discuss Your Financial Requirements?</h2>
        <div class="gold-line gold-line--center"></div>
        <p>
          Connect with our team in New Alipore, Kolkata, or submit your details online to explore suitable loan and insurance avenues.
        </p>
        <div class="final-cta-buttons">
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">Get Assistance</a>
          <a href="<?php echo esc_url(home_url('/services/')); ?>" class="btn btn-white btn-lg">Explore Services</a>
        </div>
      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>
