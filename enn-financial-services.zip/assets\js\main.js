/**
 * ENN FINANCIAL SERVICES - CORPORATE JAVASCRIPT
 * Features:
 *  - Responsive Navigation & Mobile Menu Toggle
 *  - Dropdown Menu Accessibility & Mobile Accordion
 *  - Sticky Header Dynamic Shadow & State
 *  - Back-to-Top Button
 *  - Contact Form & Career Form Validation with Toast Alerts
 *  - Dynamic Insurance & Loan Filtering
 *  - Dynamic Insights Search & Category Filtering
 *  - Accessible FAQ / Information Accordions
 */

document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  // --- 1. Sticky Header & Scroll Top Button ---
  const siteHeader = document.querySelector('.site-header');
  const scrollTopBtn = document.querySelector('.floating-btn--top');

  window.addEventListener('scroll', function () {
    const scrollY = window.pageYOffset || document.documentElement.scrollTop;
    
    if (siteHeader) {
      if (scrollY > 30) {
        siteHeader.classList.add('scrolled');
      } else {
        siteHeader.classList.remove('scrolled');
      }
    }

    if (scrollTopBtn) {
      if (scrollY > 400) {
        scrollTopBtn.classList.add('visible');
      } else {
        scrollTopBtn.classList.remove('visible');
      }
    }
  }, { passive: true });

  if (scrollTopBtn) {
    scrollTopBtn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  // --- 2. Mobile Menu & Navigation Toggle ---
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navMenu = document.querySelector('.nav-menu');
  let mobileBackdrop = document.querySelector('.mobile-backdrop');

  if (!mobileBackdrop) {
    mobileBackdrop = document.createElement('div');
    mobileBackdrop.className = 'mobile-backdrop';
    document.body.appendChild(mobileBackdrop);
  }

  function toggleMobileMenu(forceClose = false) {
    if (!navMenu) return;
    const isOpen = forceClose ? false : !navMenu.classList.contains('open');

    if (isOpen) {
      navMenu.classList.add('open');
      mobileBackdrop.classList.add('active');
      document.body.classList.add('menu-open');
      if (mobileToggle) {
        mobileToggle.setAttribute('aria-expanded', 'true');
        mobileToggle.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
      }
    } else {
      navMenu.classList.remove('open');
      mobileBackdrop.classList.remove('active');
      document.body.classList.remove('menu-open');
      if (mobileToggle) {
        mobileToggle.setAttribute('aria-expanded', 'false');
        mobileToggle.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>';
      }
    }
  }

  if (mobileToggle) {
    mobileToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      toggleMobileMenu();
    });
  }

  mobileBackdrop.addEventListener('click', function () {
    toggleMobileMenu(true);
  });

  // Mobile Dropdown Click Toggle
  const dropdownItems = document.querySelectorAll('.nav-item.has-dropdown');
  dropdownItems.forEach(function (item) {
    const link = item.querySelector('.nav-link');
    if (link) {
      link.addEventListener('click', function (e) {
        if (window.innerWidth <= 900) {
          // If clicked on mobile, toggle dropdown
          e.preventDefault();
          item.classList.toggle('open');
        }
      });
    }
  });

  // Close mobile menu on ESC
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && navMenu && navMenu.classList.contains('open')) {
      toggleMobileMenu(true);
    }
  });

  // --- 3. Toast Notification Helper ---
  function showToast(message, type = 'success') {
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      document.body.appendChild(toastContainer);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    
    const iconSvg = type === 'success' 
      ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>'
      : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>';

    toast.innerHTML = `
      <div class="toast-icon">${iconSvg}</div>
      <div class="toast-message">${message}</div>
      <button class="toast-close" aria-label="Close message">&times;</button>
    `;

    toastContainer.appendChild(toast);

    // Auto remove
    const timer = setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 300);
    }, 5500);

    toast.querySelector('.toast-close').addEventListener('click', function () {
      clearTimeout(timer);
      toast.remove();
    });
  }

  // --- 4. Contact Form Validation & Submission ---
  const contactForm = document.getElementById('enn-contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const name = contactForm.querySelector('[name="full_name"]');
      const phone = contactForm.querySelector('[name="phone"]');
      const email = contactForm.querySelector('[name="email"]');
      const service = contactForm.querySelector('[name="service"]');
      const message = contactForm.querySelector('[name="message"]');
      const consent = contactForm.querySelector('[name="consent"]');
      const submitBtn = contactForm.querySelector('button[type="submit"]');

      let isValid = true;
      let firstErrorField = null;

      function setError(input, msg) {
        isValid = false;
        if (!firstErrorField) firstErrorField = input;
        input.classList.add('is-invalid');
        let errorEl = input.parentElement.querySelector('.form-error-feedback');
        if (!errorEl) {
          errorEl = document.createElement('div');
          errorEl.className = 'form-error-feedback';
          input.parentElement.appendChild(errorEl);
        }
        errorEl.textContent = msg;
      }

      function clearError(input) {
        input.classList.remove('is-invalid');
        const errorEl = input.parentElement.querySelector('.form-error-feedback');
        if (errorEl) errorEl.textContent = '';
      }

      // Name validation
      if (!name.value.trim() || name.value.trim().length < 2) {
        setError(name, 'Please enter your full name (minimum 2 characters).');
      } else {
        clearError(name);
      }

      // Phone validation (numbers, spaces, +, min 10 digits)
      const phoneClean = phone.value.replace(/[\s\-\(\)]/g, '');
      const phoneRegex = /^[+]?[0-9]{10,15}$/;
      if (!phoneRegex.test(phoneClean)) {
        setError(phone, 'Please enter a valid 10-digit mobile number.');
      } else {
        clearError(phone);
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.value.trim())) {
        setError(email, 'Please enter a valid email address.');
      } else {
        clearError(email);
      }

      // Service selection
      if (!service.value) {
        setError(service, 'Please select the service category you require.');
      } else {
        clearError(service);
      }

      // Consent check
      if (consent && !consent.checked) {
        setError(consent, 'Please agree to the privacy policy to proceed.');
      } else if (consent) {
        clearError(consent);
      }

      if (!isValid) {
        if (firstErrorField) firstErrorField.focus();
        showToast('Please correct the highlighted fields before submitting.', 'error');
        return;
      }

      // Show submitting state
      const originalBtnText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner"></span> Submitting Enquiry...';

      // Simulate clean submission handling
      setTimeout(function () {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
        contactForm.reset();

        showToast(
          'Thank you for contacting ENN Financial Services. Your enquiry has been received. Our team will review your requirements and connect with you shortly at the provided contact details.',
          'success'
        );

        // Show inline success message container if present
        const formResponse = document.getElementById('contact-form-response');
        if (formResponse) {
          formResponse.className = 'alert alert--success';
          formResponse.innerHTML = `
            <strong>Enquiry Successfully Received!</strong>
            <p>Thank you for reaching out to ENN Financial Services. A representative will contact you shortly to understand your requirements.</p>
            <p class="text-sm">Destination: ennfinancialservices.kol@gmail.com</p>
          `;
          formResponse.style.display = 'block';
        }
      }, 1000);
    });
  }

  // --- 5. Career Profile Form Validation & Submission ---
  const careerForm = document.getElementById('enn-career-form');
  if (careerForm) {
    careerForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const name = careerForm.querySelector('[name="career_name"]');
      const email = careerForm.querySelector('[name="career_email"]');
      const phone = careerForm.querySelector('[name="career_phone"]');
      const role = careerForm.querySelector('[name="career_role"]');
      const submitBtn = careerForm.querySelector('button[type="submit"]');

      if (!name.value.trim() || !email.value.trim() || !phone.value.trim()) {
        showToast('Please fill in your name, email and contact number.', 'error');
        return;
      }

      const originalBtnText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner"></span> Processing...';

      setTimeout(function () {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
        careerForm.reset();

        showToast(
          'Thank you for submitting your profile to ENN Financial Services. Your details have been recorded for future career opportunities.',
          'success'
        );

        const careerFeedback = document.getElementById('career-form-response');
        if (careerFeedback) {
          careerFeedback.className = 'alert alert--success';
          careerFeedback.innerHTML = `
            <strong>Profile Submitted Successfully</strong>
            <p>We appreciate your interest in ENN Financial Services. When a suitable opening arises matching your expertise, our HR coordination team will reach out.</p>
          `;
          careerFeedback.style.display = 'block';
        }
      }, 900);
    });
  }

  // --- 6. Live Filter / Search for Insurance & Loan Categories ---
  const serviceSearchInput = document.getElementById('service-search-input');
  const serviceCategoryFilter = document.querySelectorAll('.service-filter-btn');
  const insuranceCards = document.querySelectorAll('.insurance-grid .category-card');
  const loanCards = document.querySelectorAll('.loans-grid .loan-card');

  function filterServiceItems() {
    const query = serviceSearchInput ? serviceSearchInput.value.toLowerCase().trim() : '';
    const activeFilterBtn = document.querySelector('.service-filter-btn.active');
    const activeType = activeFilterBtn ? activeFilterBtn.dataset.filter : 'all';

    // Handle insurance cards
    insuranceCards.forEach(function (card) {
      const title = card.querySelector('h3, h4')?.textContent.toLowerCase() || '';
      const desc = card.querySelector('p')?.textContent.toLowerCase() || '';
      const matchesQuery = query === '' || title.includes(query) || desc.includes(query);
      const matchesType = activeType === 'all' || activeType === 'insurance';

      if (matchesQuery && matchesType) {
        card.style.display = '';
      } else {
        card.style.display = 'none';
      }
    });

    // Handle loan cards
    loanCards.forEach(function (card) {
      const title = card.querySelector('h3, h4')?.textContent.toLowerCase() || '';
      const desc = card.querySelector('p')?.textContent.toLowerCase() || '';
      const matchesQuery = query === '' || title.includes(query) || desc.includes(query);
      const matchesType = activeType === 'all' || activeType === 'loans';

      if (matchesQuery && matchesType) {
        card.style.display = '';
      } else {
        card.style.display = 'none';
      }
    });
  }

  if (serviceSearchInput) {
    serviceSearchInput.addEventListener('input', filterServiceItems);
  }

  serviceCategoryFilter.forEach(function (btn) {
    btn.addEventListener('click', function () {
      serviceCategoryFilter.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      filterServiceItems();
    });
  });

  // --- 7. Insights Blog Search & Filter ---
  const blogSearchInput = document.getElementById('blog-search-input');
  const blogCategoryPills = document.querySelectorAll('.insight-category-pill');
  const blogCards = document.querySelectorAll('.insight-card');

  function filterBlogPosts() {
    const query = blogSearchInput ? blogSearchInput.value.toLowerCase().trim() : '';
    const activePill = document.querySelector('.insight-category-pill.active');
    const selectedCategory = activePill ? activePill.dataset.category : 'all';

    let visibleCount = 0;

    blogCards.forEach(function (card) {
      const title = card.querySelector('h3, h4')?.textContent.toLowerCase() || '';
      const excerpt = card.querySelector('p')?.textContent.toLowerCase() || '';
      const cardCat = card.dataset.category || '';

      const matchesQuery = query === '' || title.includes(query) || excerpt.includes(query);
      const matchesCategory = selectedCategory === 'all' || cardCat === selectedCategory;

      if (matchesQuery && matchesCategory) {
        card.style.display = '';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });

    const noResultsEl = document.getElementById('blog-no-results');
    if (noResultsEl) {
      noResultsEl.style.display = visibleCount === 0 ? 'block' : 'none';
    }
  }

  if (blogSearchInput) {
    blogSearchInput.addEventListener('input', filterBlogPosts);
  }

  blogCategoryPills.forEach(function (pill) {
    pill.addEventListener('click', function (e) {
      e.preventDefault();
      blogCategoryPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      filterBlogPosts();
    });
  });

  // --- 8. Accessible Accordions ---
  const accordionTriggers = document.querySelectorAll('.accordion-header');
  accordionTriggers.forEach(function (header) {
    header.addEventListener('click', function () {
      const item = header.parentElement;
      const isOpen = item.classList.contains('active');

      // Close all other items in same accordion group
      const parentGroup = item.closest('.accordion-group');
      if (parentGroup) {
        parentGroup.querySelectorAll('.accordion-item').forEach(function (sibling) {
          sibling.classList.remove('active');
          const siblingBtn = sibling.querySelector('.accordion-header');
          if (siblingBtn) siblingBtn.setAttribute('aria-expanded', 'false');
        });
      }

      if (!isOpen) {
        item.classList.add('active');
        header.setAttribute('aria-expanded', 'true');
      } else {
        item.classList.remove('active');
        header.setAttribute('aria-expanded', 'false');
      }
    });
  });

});
