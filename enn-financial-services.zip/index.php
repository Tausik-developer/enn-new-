<?php
/**
 * Main Index & Insights Blog Listing Template
 *
 * @package ENN_Financial_Services
 */

get_header(); ?>

<main id="main-content">
  
  <section class="page-banner">
    <div class="container">
      <div class="page-banner-content">
        <div class="breadcrumbs">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span>/</span>
          <span>Insights</span>
        </div>
        <h1>Financial Insights & Updates</h1>
        <p class="page-banner-desc">
          Expert perspectives, educational commentary, and practical guides on personal finance, loan processes, MSME funding, and insurance awareness.
        </p>
      </div>
    </div>
  </section>

  <!-- SEARCH & CATEGORY FILTER BAR -->
  <section class="section section--sm" style="padding-bottom: 20px;">
    <div class="container">
      <div class="insight-filter-bar">
        <div class="insight-categories">
          <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/insights/')); ?>" class="insight-category-pill <?php echo !is_category() ? 'active' : ''; ?>">All Topics</a>
          <?php
          $categories = get_categories(array('hide_empty' => false));
          foreach ($categories as $cat) {
              $active_class = is_category($cat->term_id) ? 'active' : '';
              echo '<a href="' . esc_url(get_category_link($cat->term_id)) . '" class="insight-category-pill ' . esc_attr($active_class) . '">' . esc_html($cat->name) . '</a>';
          }
          ?>
        </div>

        <div class="service-search-box" style="margin-left: auto;">
          <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
            <svg class="service-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="search" name="s" id="blog-search-input" value="<?php echo get_search_query(); ?>" placeholder="Search insights and guides..." aria-label="Search insights">
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- POSTS GRID -->
  <section class="section section--offwhite">
    <div class="container">
      
      <?php if (have_posts()) : ?>
        <div class="insights-grid">
          <?php while (have_posts()) : the_post(); ?>
            <article class="insight-card">
              <div class="insight-thumb-wrap">
                <?php if (has_post_thumbnail()) : ?>
                  <?php the_post_thumbnail('enn-insight-thumb'); ?>
                <?php else : ?>
                  <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/insight-personal-finance.jpg'); ?>" alt="<?php the_title_attribute(); ?>" width="380" height="200">
                <?php endif; ?>
                <span class="insight-badge">
                  <?php
                  $cats = get_the_category();
                  echo !empty($cats) ? esc_html($cats[0]->name) : 'Insight';
                  ?>
                </span>
              </div>
              <div class="insight-card-content">
                <div class="insight-meta">
                  <span><?php echo get_the_date('F Y'); ?></span>
                  <span>•</span>
                  <span><?php echo ceil(str_word_count(strip_tags(get_the_content())) / 200) . ' Min Read'; ?></span>
                </div>
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                <a href="<?php the_permalink(); ?>" class="insight-read-more">Read Article →</a>
              </div>
            </article>
          <?php endwhile; ?>
        </div>

        <!-- WordPress Pagination -->
        <div style="margin-top: 50px; text-align: center;">
          <?php
          the_posts_pagination(array(
              'prev_text' => __('← Previous', 'enn-finance'),
              'next_text' => __('Next →', 'enn-finance'),
          ));
          ?>
        </div>

      <?php else : ?>
        <div style="text-align: center; padding: 60px 0;">
          <h3>No articles found</h3>
          <p>Please check back soon for our latest publications or try a different search keyword.</p>
        </div>
      <?php endif; ?>

    </div>
  </section>

  <!-- FINAL CTA -->
  <section class="final-cta-section">
    <div class="container">
      <div class="final-cta-box">
        <div class="eyebrow eyebrow--center" style="color: var(--color-gold-light);">HAVE QUESTIONS?</div>
        <h2>Need Personalized Financial Guidance?</h2>
        <div class="gold-line gold-line--center"></div>
        <p>
          Connect with the ENN Financial Services team to explore suitable loan options and insurance categories for your specific profile.
        </p>
        <div class="final-cta-buttons">
          <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">Get Assistance</a>
          <a href="<?php echo esc_url(home_url('/services/')); ?>" class="btn btn-white btn-lg">Explore Solutions</a>
        </div>
      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>
